# include "minishell.h"

void exit_by_error(int code)
{

	/* ready for exit ...*/
	// 1 : malloc error

	// code = ...

	exit(code);
}